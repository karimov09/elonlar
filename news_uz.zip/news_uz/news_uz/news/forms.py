from django import forms
from .models import elon

class ElonForm(forms.ModelForm):
    class Meta:
        model = elon
        fields = ['title', 'description', 'image', 'category']
