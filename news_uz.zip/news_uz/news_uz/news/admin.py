from django.contrib import admin
from .models import Category, News

class NewsAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'content', 'category', 'published_date', 'image') 
    list_display_links = ('id', 'title')  
    list_filter = ('category', 'published_date')  
    search_fields = ('content', 'title')  

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')  
    list_display_links = ('id', 'name') 
    search_fields = ('name',)  

admin.site.register(Category, CategoryAdmin)
admin.site.register(News, NewsAdmin)
